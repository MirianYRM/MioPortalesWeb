This template / effect / code has been created by kootoopas.
You can customize and check it out on its original site on the following link:
https://codepen.io/kootoopas/pen/reyqg

Thank you